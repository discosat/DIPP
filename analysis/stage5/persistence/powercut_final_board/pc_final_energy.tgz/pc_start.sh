#!/bin/sh
cd /home/root/tmp-experiments
set -a
. ./dawndusk-3w7.env
set +a
export DIPP_BATT_SOC0=0.45194 DIPP_BATT_PHASE0=0.1202
export STORAGE_MODE=HYBRID
export DIPP_SCHED_Q_MED=auto
export DIPP_SCHED_Q_LOW=auto
export DIPP_SCHED_GRANULARITY=stage
export DIPP_SCHED_GATE_MED_MS=5000
export DIPP_SCHED_GATE_LOW_MS=3000
export DIPP_SCHED_WINDOW=8
export DIPP_SCHED_FRAME_OVERHEAD_MS=780
export DIPP_SCHED_GUARD=on
export DIPP_SCHED_ACCEPT=feas
export DIPP_SCHED_K_X10=20
export DIPP_SCHED_SMAX_HIGH_MS=12150
export DIPP_SCHED_SMAX_MED_MS=7330
export DIPP_SCHED_ENERGY=on
setsid ./dipp -i CAN -p can0 -a 5423 >> pc.log 2>&1 &
